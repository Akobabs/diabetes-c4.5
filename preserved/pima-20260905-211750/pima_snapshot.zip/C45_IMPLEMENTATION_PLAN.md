# Implementation plan: Prediction of Diabetes Using C4.5

Prepared from `TAIWO_FAROTIMI_Proposal_UPDATED.docx`, `diabetes.csv`, `diabetes1.csv`, and the repository contents on 5 September 2026. Implementation now uses the downloaded Pima data, Python and Streamlit. See README.md for executable commands and results/full for experimental outputs; the phases below describe the research design.

**Implementation status (5 September 2026):** the Python pipeline, full nested evaluation, final J48 model, Streamlit prototype, generated research report and nine passing tests are complete. Pooled held-out J48 accuracy is 74.35%, sensitivity 75.37%, and ROC-AUC 0.8117. These results do not establish clinical readiness. See [docs/IMPLEMENTATION_RESULTS.md](docs/IMPLEMENTATION_RESULTS.md) for comparisons and limitations, and [docs/USER_GUIDE.md](docs/USER_GUIDE.md) for operation.

## 1. Research requirements

The document contains a proposal organised into 11 numbered sections and references, rather than three separately labelled chapters. Its substantive requirements are:

1. Design a framework for diabetes classification, handling missing data, outliers, and class imbalance.
2. Train and tune a C4.5 decision tree using WEKA J48, including pruning.
3. Build a prototype accepting clinical attributes and showing a prediction and the responsible decision rule.
4. Compare C4.5 against Naive Bayes and Logistic Regression.
5. Evaluate with stratified ten-fold cross-validation and accuracy, precision, recall/sensitivity, specificity, F1, ROC-AUC, and confusion matrices.

The stated scope is the Pima dataset: 768 records, eight predictors, an outcome label, and female participants aged at least 21. Clinical deployment is outside the proposal's scope.

## 2. Actual folder findings and the first decision

At initial inspection, the folder contained the proposal, two CSV files, a minimal README, and Git configuration, with no application or training implementation. The dataset findings below describe those originally supplied files.

| Check | Actual finding |
|---|---|
| Dataset size | Each CSV contains 403 records and 19 columns |
| File relationship | Byte-for-byte identical SHA-256 hashes; these are duplicate copies, not independent datasets |
| Within-file duplicates | 403 distinct data lines in each file |
| Outcome | No explicit `Outcome`, diabetes diagnosis, or binary target column |
| Participants | 234 rows marked female and 169 marked male |
| Attributes | `id`, `chol`, `stab.glu`, `hdl`, `ratio`, `glyhb`, `location`, `age`, `gender`, `height`, `weight`, `frame`, `bp.1s`, `bp.1d`, `bp.2s`, `bp.2d`, `waist`, `hip`, `time.ppn` |
| Major missingness | `bp.2s` and `bp.2d`: 262 missing each; `glyhb`: 13; `frame`: 12 |
| Other missingness | `height`, `bp.1s`, `bp.1d`: 5 each; `time.ppn`: 3; `waist`, `hip`: 2 each; `chol`, `hdl`, `ratio`, `weight`: 1 each |
| Numeric zero entries | No literal numeric zeros found; the proposal's Pima zero-replacement rule does not describe these supplied files |

Both files have SHA-256 `3DE140BA6771EE5AF7043500065C667CFB5C059EB840CC22E14CABF1EBFC0838`.

Their schema, dimensions, and missingness match the [Vanderbilt biostatistics diabetes data dictionary](https://hbiostat.org/data/repo/cdiabetes). This strongly suggests that dataset family, but the original download source still needs recording.

**Recommended route: retain the proposal's Pima study design. A verified copy is now downloaded from OpenML dataset 37, version 1.** Use `data/derived/pima_diabetes.csv` for Python training; the unchanged source is `data/raw/pima_diabetes.arff`. Verification found 768 distinct records, eight predictors, and 500 negative / 268 positive outcome labels; the source MD5 matches OpenML metadata. See [data/README.md](data/README.md) for provenance, column mapping, missing-value indicators and checksums. Preserve the originally supplied CSVs as received; do not combine them with Pima, treat one as a test set, or rename their columns to imitate Pima data.

Proceed with the downloaded Pima dataset as the recommended implementation input. If the original 403-record data must be used instead, revise the dataset description, study population, predictors, missing-data approach, and outcome definition before training. The alternative route is detailed in section 9. Cite OpenML as the actual download location and retain the original dataset attribution in the dissertation.

## 3. Methodology corrections

- Replace class-specific median imputation with medians learned from training predictors without using the outcome. A new patient's class is unknown; using validation labels to choose medians leaks the answer into the inputs.
- Fit imputation, scaling, outlier thresholds, feature selection, and resampling independently inside every training fold. Validation records retain their original class distribution and are never oversampled.
- Separate parameter selection from performance estimation using nested cross-validation. Using the same ten folds both to choose the best configuration and report its score gives an optimistic estimate.
- Keep all eight Pima predictors as the reference model. Treat a reduced feature set as a candidate selected inside training folds, not an automatic improvement.
- Inspect outliers and document them. Retain valid extreme observations; do not remove patients solely for having unusual values. Compare any training-derived capping policy against retaining extremes, without deleting difficult validation cases.
- Include SMOTE as a planned experimental condition and compare it with no resampling. Select using validation evidence rather than assuming it improves the model.

These changes should be reflected in Chapter 3 before final reporting. The general rule that preprocessing must learn only from training data is documented in [scikit-learn's leakage guidance](https://scikit-learn.org/stable/common_pitfalls.html).

## 4. Implementation architecture

Use **Python for data preparation, training orchestration, tuning, evaluation, and prediction**, with **Streamlit as the default prototype interface**. A JavaScript/TypeScript frontend is an alternative when a more customised interface is needed.

| Component | Planned technology and purpose |
|---|---|
| Data processing | pandas and NumPy for CSV auditing and feature transformations |
| C4.5 training | `python-weka-wrapper3` calling WEKA J48 from Python |
| Baselines and evaluation | scikit-learn GaussianNB, LogisticRegression, cross-validation splits and metrics |
| Resampling | imbalanced-learn SMOTE, or SMOTENC for the alternative mixed-type dataset |
| Research figures | Matplotlib and seaborn; exported tree diagrams |
| Default prototype | Streamlit input form, prediction explanation and evaluation dashboard |
| Alternative frontend | React with TypeScript, communicating with a Python FastAPI service |
| Persistence | WEKA serialization for J48, joblib for Python preprocessing, JSON for schema and experiment metadata |

The Python wrapper preserves the proposal's J48 implementation, but **a compatible Java runtime remains a dependency** for training and inference. The project application code and experiment scripts will be Python. Confirm the wrapper, Python and JDK combination on Windows and pin the working versions; see the [wrapper installation guide](https://fracpete.github.io/python-weka-wrapper3/install.html). A pure-Python reimplementation would be a separate methodology choice requiring validation of C4.5 splitting, missing-value behaviour and pruning.

Streamlit interfaces are written in Python and run in the browser; JavaScript/TypeScript is not required for the standard prototype. See [Streamlit's basic concepts](https://docs.streamlit.io/get-started/fundamentals/main-concepts). Build one interface initially: Streamlit is the default assumption for this plan. If React/TypeScript is selected, expose the same Python prediction service through [FastAPI](https://fastapi.tiangolo.com/) rather than duplicating preprocessing or prediction logic in the browser.

WEKA J48 implements C4.5 and supports pruning controls and tree export: see the [official J48 API](https://weka.sourceforge.io/doc.stable/weka/classifiers/trees/J48.html). Do not substitute scikit-learn's `DecisionTreeClassifier(criterion="entropy")`: its tree implementation is CART, as explained in the [scikit-learn tree documentation](https://scikit-learn.org/stable/modules/tree.html).

```mermaid
flowchart TD
    A[Verified data and target definition] --> B[Schema checks and saved outer folds]
    B --> C[Python inner-fold preprocessing and tuning]
    C --> D[J48 through Python wrapper plus sklearn baselines]
    D --> E[Predictions on untouched outer folds]
    E --> F[Metrics, comparison, figures and research results]
    F --> G[Retune chosen J48 procedure on all eligible data]
    G --> H[Save model, preprocessing and feature schema]
    H --> I[Streamlit form or TypeScript frontend with Python API]
    I --> J[Prediction, model score and actual decision path]
```

The final all-data model is for the demonstration. Its training score is not the reported generalisation result.

## 5. Phased implementation

### Phase 1 — Confirm data and create the project

- Resolve Pima versus supplied-data scope and record the source, usage terms, data dictionary, label meaning, and file hash.
- Create a Python package with `pyproject.toml`, an isolated environment and locked dependencies. Verify local Python availability, then run a small J48 training, score prediction and serialization round trip through `python-weka-wrapper3`.
- Verify the compatible JDK and Python architecture on Windows. Keep the wrapper behind a Python adapter so the rest of the project uses a consistent `fit`, `predict`, `predict_proba` and artifact-loading interface.
- Add configuration for feature names, units, missing-value rules, positive class, seed, folds, model parameters, and output paths.
- Preserve source data and generate derived files separately. Reject incompatible schemas immediately.

**Deliverable:** reproducible setup, agreed dataset contract, and data audit.

### Phase 2 — Explore and preprocess

- Produce distributions, missingness summaries, class counts, duplicate checks, and descriptive statistics.
- For Pima only, map zero glucose, blood pressure, skin thickness, insulin, and BMI to missing. Preserve valid zero pregnancies.
- Fit training-fold numeric medians and apply those saved medians at validation and inference time. Explicitly handle any entirely missing training column.
- Evaluate outlier handling and an optional reduced feature set within training folds. The implementation uses training-only mutual information with a fixed random seed, comparing the top five predictors with all eight. This is a feature ranking procedure, not a J48 impurity-importance API. Outlier candidates retain extremes or cap at training-derived 1.5-IQR bounds.
- For SMOTE, fit numeric scaling on training data to avoid distance calculations being dominated by units. Resample training observations only; transform synthetic numeric values back to original units before fitting J48 so its rules remain readable. Document the treatment of synthetic fractional values in count variables.
- Scale inputs for Logistic Regression using training statistics. Keep baseline-specific transforms inside the same evaluation boundaries.

**Deliverable:** reusable preprocessing component, exploratory report, and a transformation manifest.

### Phase 3 — Implement and tune genuine C4.5

- Use `weka.classifiers.trees.J48` through `python-weka-wrapper3` with pruning enabled. Python owns the training loop, preprocessing and parameter search; the wrapper invokes the C4.5 engine.
- Convert processed pandas/NumPy data to WEKA instances using an explicit schema, nominal target and fixed class order. Reuse the saved training header during inference. The adapter must support fresh independent models per fold and align probability columns with the declared positive class.
- Start with the documented defaults: confidence factor 0.25 and minimum instances per leaf 2.
- Proposed initial search: confidence factor `{0.05, 0.10, 0.25, 0.40}` and minimum instances per leaf `{2, 5, 10, 20}`. Keep other settings fixed initially to limit search complexity.
- Compare cleaned-data J48 with and without SMOTE. Expand the search only if the initial experiment identifies a specific need.
- Define ROC-AUC as the primary configuration-selection metric, with sensitivity and tree size reported alongside it. Predeclare a deterministic tie-break favouring the smaller tree.
- Export the tree, leaf count, tree size, and human-readable rules. Implement prediction-path tracing against the actual fitted tree or a structured export, and check agreement with J48 predictions.

**Deliverable:** configurable J48 trainer, saved tree, and verified explanation extraction.

### Phase 4 — Evaluate and compare

- Use a fixed stratified outer ten-fold split for every classifier. Within each outer training partition, use stratified five-fold validation to tune preprocessing and model settings.
- Fit every transform from scratch within each inner training fold; after tuning, refit on the outer training partition and predict its untouched outer validation partition.
- Train scikit-learn GaussianNB and LogisticRegression using the same outer partitions, eligible source rows, and candidate resampling conditions. Predeclare modest baseline tuning ranges for GaussianNB `var_smoothing` and LogisticRegression `C`, using a compatible solver and L2 regularisation. Record implementation names in the report, including the Gaussian likelihood assumption for Naive Bayes.
- Save one outer-fold predicted label and positive-class score for each eligible original record. Define positive class explicitly and prevent class-order mistakes.
- Report accuracy, precision, sensitivity, specificity, F1, ROC-AUC, and confusion matrices. Compute AUC from scores, not hard labels. Report fold mean and standard deviation, plus pooled out-of-fold metrics clearly labelled as such.
- Show ROC curves, a model comparison table, and a tree diagram. If confidence intervals are provided, document the method and its limitations with dependent cross-validation fits.
- Use the default probability threshold 0.5 for the principal binary results. Any threshold optimisation must happen only inside inner validation and be reported separately.
- Include controlled comparisons for missing-value handling, pruning, and SMOTE. Do not promise a particular accuracy or that J48 will outperform the baselines.

**Deliverable:** reproducible results CSVs, metrics tables, plots, parameter logs, and interpretation of false positives and false negatives.

### Phase 5 — Package the final model and prototype

- Select the final J48 procedure using the predefined evaluation protocol, tune it on the full eligible dataset, and refit for demonstration use.
- Save J48 with WEKA serialization and the Python preprocessing with joblib, together with a JSON manifest containing selected feature order, units, class mapping, configuration, dependency versions and dataset hash. Save the WEKA training header as well. Do not attempt to pickle a live JVM classifier as an ordinary scikit-learn model.
- Build a shared Python prediction service used by both evaluation checks and the interface. Start with Streamlit pages for patient inputs, prediction and explanation, and saved research results.
- Manage JVM startup once per server process. Cache the loaded inference resources across Streamlit reruns, protect shared inference access as needed, and do not start or stop the JVM for every form submission. Keep patient-specific inputs in session state rather than shared model resources.
- If the TypeScript option is chosen, build React pages backed by FastAPI endpoints such as `POST /predict`, `GET /model-info` and `GET /metrics`. Validate requests with a shared documented schema and return class, score, rule path, imputed fields and model version. Keep this optional API outside the default Streamlit implementation.
- For the Pima route, provide fields for pregnancies, glucose, blood pressure, skin thickness, insulin, BMI, diabetes pedigree function, and age. Obtain precise units and measurement definitions from the verified data dictionary.
- Validate types and ranges; distinguish unknown values from actual zeros. Show when a missing input was imputed. Do not request an outcome from the user.
- Return predicted class, an explicitly labelled model score, the actual traversed decision rule, and model version. Avoid describing an uncalibrated score as a medically validated risk percentage.
- Add a read-only research results page displaying the saved evaluation metrics and tree. State the proposal's limited population and research-prototype scope concisely.
- Load the saved model for inference rather than retraining on each request. Patient storage, authentication, cloud deployment, and hospital integration are not needed for this prototype.

**Deliverable:** working local application whose output agrees with the saved J48 model.

### Phase 6 — Verify and prepare the report

- Test prevention of target/ID leakage, train-only fitting, duplicate split contamination, and accidental SMOTE on validation data.
- Verify handling of missing inputs, feature order, invalid values, unseen categories if relevant, class mapping, and serialization round trips.
- Confirm that exported rule paths and interface predictions agree with direct J48 inference on representative records and split boundaries.
- Rerun the documented experiment with the same seed and verify saved fold assignments and reproducible outputs.
- Prepare Chapter 4: implementation, environment, data audit, experiments, model comparison, tree interpretation, and screenshots.
- Prepare Chapter 5: findings tied to objectives, limitations, conclusion, and future external validation.
- Update Chapter 3 to match the actual implemented data source, preprocessing, and nested validation protocol. Check literature claims against their original papers when preparing the final dissertation.

**Deliverable:** tested prototype, repeatable experiment commands, README, figures, and material for Chapters 4–5.

## 6. Suggested project layout

```text
pyproject.toml
requirements.lock        # Resolved versions produced during setup
README.md
C45_IMPLEMENTATION_PLAN.md
config/experiment.json
data/raw/                 # Immutable verified source data
data/derived/             # Generated, never manually treated as source
src/diabetes_c45/data.py          # Loading and schema checks
src/diabetes_c45/preprocessing.py # Fold-fitted transformations
src/diabetes_c45/j48_adapter.py   # Python interface to WEKA C4.5
src/diabetes_c45/train.py         # Training and parameter search
src/diabetes_c45/evaluate.py      # Nested CV and metrics
src/diabetes_c45/predict.py       # Shared inference service
src/diabetes_c45/explain.py       # Faithful decision paths
app/streamlit_app.py             # Default prototype
tests/                          # Leakage, inference and integration checks
notebooks/                      # Optional exploratory analysis
artifacts/               # Final model and preprocessing manifest
results/                 # Fold predictions, metrics and figures
docs/                    # Data dictionary, methodology and user guide
```

If the TypeScript frontend is selected, replace `app/streamlit_app.py` with `frontend/` for React/TypeScript and `api/main.py` for FastAPI. Both options use the same `diabetes_c45` Python package and model artifacts. The proposed Streamlit launch command after installation is `python -m streamlit run app/streamlit_app.py`; training and evaluation will expose Python module commands.

## 7. Indicative schedule

| Week | Milestone |
|---|---|
| 1 | Resolve dataset, establish setup, audit data and finalise methodology |
| 2 | Implement preprocessing and initial J48 experiments |
| 3 | Complete nested evaluation, baseline comparisons and rule extraction |
| 4 | Build and integrate the prediction prototype |
| 5 | Verify reproducibility, prepare figures and write implementation/results material |

This is an estimate after dataset and target resolution, not a guaranteed completion date.

## 8. Completion criteria

The project is complete when the selected dataset and outcome are documented; J48 C4.5 is demonstrably used; all learned preprocessing and tuning respect fold boundaries; required metrics and baselines are reproducible; and the application returns predictions with faithful rules from the saved model. Every research objective should map to an implementation artifact and a report section. Honest results and reproducibility determine completion, rather than a predetermined accuracy target.

## 9. Alternative if the supplied 403-record dataset is retained

1. Use a single CSV. Record that it is not the Pima dataset and amend population and feature descriptions.
2. Establish a defensible supervised target with the supervisor and source documentation. `glyhb` is a continuous measurement, not an existing binary diagnosis label. Do not silently choose a threshold or claim that a derived label establishes Type 2 diabetes or future disease onset.
3. If an explicitly justified research label is derived from `glyhb`, exclude `glyhb` and all target-derived fields from predictors. Exclude the 13 records with missing `glyhb` from supervised fitting and evaluation, leaving 390 potentially labelled records; do not impute the target.
4. Exclude `id` as a predictor. Initially exclude `bp.2s` and `bp.2d`, each missing in about 65% of records, and document the choice. Assess whether `location` is a site shortcut and whether it belongs in the intended prediction inputs.
5. Use numeric median and categorical mode imputation fitted inside training folds. Encode categories appropriately for each baseline while allowing J48 to use nominal attributes.
6. Optional derived BMI must use verified source units: the matching dictionary lists height in inches and weight in pounds. Derived features must not depend on the target.
7. Confirm class counts after defining the outcome and ensure that both outer and inner folds contain sufficient positive cases. Any necessary reduction in fold count must be documented as a methodology revision.
8. Use a resampling method that preserves categorical features, such as an explicitly verified mixed-data SMOTE implementation; ordinary numeric interpolation must not create fractional category codes.
9. Adapt the interface to the final retained predictors. Describe the model as predicting the defined research label, with limitations appropriate to this dataset.

This route can support a C4.5 project, but its research question and evaluation population would differ from the current proposal.
