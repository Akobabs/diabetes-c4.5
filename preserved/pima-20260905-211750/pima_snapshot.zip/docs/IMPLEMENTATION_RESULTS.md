# Implementation and results draft

Generated from the completed experiment; these are observed results, not target performance figures.

## Implementation

Python 3.12.14 controls preprocessing, nested validation and WEKA 3.9.7 J48 through python-weka-wrapper3. Java 17.0.20.1 supplies the runtime. Streamlit provides the local prototype. The dataset contains 768 records, with 500 negative and 268 positive original outcomes.

The original proposal's class-specific imputation was replaced with training-fold predictor medians. Ten stratified outer folds estimate generalisation, with five inner folds selecting preprocessing and model settings. Positive predictions use score >= 0.5. SMOTE, when selected, affects training records only. Five-feature selection uses training-only mutual information; optional outlier capping uses training-derived 1.5-IQR bounds.

## Main results: pooled outer-fold predictions

| Model | Accuracy | Precision | Sensitivity | Specificity | F1 | ROC-AUC |
|---|---:|---:|---:|---:|---:|---:|
| J48 | 0.7435 | 0.6066 | 0.7537 | 0.7380 | 0.6722 | 0.8117 |
| Naive Bayes | 0.7396 | 0.6062 | 0.7239 | 0.7480 | 0.6599 | 0.8217 |
| Logistic Regression | 0.7669 | 0.6831 | 0.6194 | 0.8460 | 0.6497 | 0.8233 |

## Fold means and standard deviations

| Model | Accuracy | Sensitivity | ROC-AUC |
|---|---:|---:|---:|
| J48 | 0.7433 ± 0.0508 | 0.7537 ± 0.1009 | 0.8111 ± 0.0520 |
| Naive Bayes | 0.7394 ± 0.0605 | 0.7238 ± 0.1356 | 0.8288 ± 0.0546 |
| Logistic Regression | 0.7668 ± 0.0594 | 0.6191 ± 0.1305 | 0.8279 ± 0.0493 |

## Interpretation

Across held-out records, tuned J48 produced 202 true positives, 66 false negatives, 369 true negatives and 131 false positives. Logistic Regression had the highest pooled ROC-AUC among the three main classifiers in this run. This is a descriptive comparison, not evidence of statistical significance.

The majority-class reference accuracy is 500/768 = 65.10%, but always predicting negative would have zero sensitivity. Accuracy should therefore be read together with sensitivity, specificity and AUC.

## Controlled preprocessing and pruning comparisons

| Fixed J48 configuration | Accuracy | Sensitivity | ROC-AUC |
|---|---:|---:|---:|
| J48 SMOTE | 0.7214 | 0.7500 | 0.7478 |
| J48 capped | 0.7461 | 0.6642 | 0.7677 |
| J48 five features | 0.7383 | 0.6828 | 0.7809 |
| J48 reference | 0.7539 | 0.6754 | 0.7796 |
| J48 unpruned | 0.7578 | 0.6828 | 0.7759 |
| J48 zeros untreated | 0.7630 | 0.6418 | 0.7642 |

These use default confidence 0.25 and minimum leaf size 2 unless pruning is disabled. The reference uses median imputation, all eight predictors, no capping and no resampling. Each other row changes just the named component. They share the outer folds and do not select settings using outer validation scores.

## Final demonstration model

After evaluation, J48 was retuned on all records and fitted with {'smote': False, 'cap_outliers': False, 'feature_count': 5, 'confidence': 0.25, 'min_leaf': 20}. The saved tree has 13 nodes and 7 leaves. Retained predictors: Pregnancies, Glucose, BMI, DiabetesPedigreeFunction, Age.

The prototype follows actual J48 split objects and reports imputation or clipping. Its model score is not presented as a calibrated clinical risk. The full-data tree is different from the outer-fold models; the reported generalisation metrics evaluate the training procedure, not an independent test of this exact final tree.

## Limitations and conclusion

The data are small and restricted to the source population. Missing indicators are extensive in insulin and skin thickness. Random cross-validation is internal validation, not evidence of performance in Nigerian clinics or other populations. Synthetic count features can be fractional after SMOTE. Scores were not calibrated, and fold standard deviations are not confidence intervals. The label does not define a future forecast horizon.

The implementation demonstrates a reproducible and interpretable C4.5 classification workflow and a working research interface. External validation, prospective evaluation and probability calibration are appropriate future work. Do not claim clinical readiness or that preprocessing always improves every metric.

## Evidence for Chapters 4 and 5

Use results/full/comparison.csv, fold_metrics.csv, predictions.csv, folds.json and search logs as the numeric evidence. Figures include roc_curves.png, confusion matrices, feature_distributions.png, correlations.png and missingness.png. The final tree is in artifacts/final/tree.dot and tree.txt. Dataset attribution and measurement definitions are in data/README.md. Update Chapter 3 to match this implemented protocol before incorporating these results.
